#ifndef _XP520_H_
#define _XP520_H_

#include "common.h"

#if(XP_ID==XP520)








#endif

#endif

