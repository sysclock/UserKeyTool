
#ifndef _ESP8266_H_
#define _ESP8266_H_

void InitEsp8266(void);



#endif





