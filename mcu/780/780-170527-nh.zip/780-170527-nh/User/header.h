#ifndef HEADER_H
#define HEADER_H

#define DEBUG88 


#include <stdio.h>
#include "stm32f10x.h"
#include "lcd.h"
#include "common.h"
#include "keypad.h"
#include "statedata.h"
#include "USART.h"
#include "i2c.h"
#include "date.h"	 
#include "sendmsg.h"
#include "statemachine.h"
#include "strings.h"
#include "menutbl.h"
#include "RTC.h"
#include "delay.h"
#include "USART.h"
#include "Flash.h"
#include "Remote.h"

#include "screen-set.h"
#include "display.h"

#include "ColorDisplay.h"

//extern U8 Buf[12];






#endif

